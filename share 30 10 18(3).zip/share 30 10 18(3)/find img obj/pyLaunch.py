import os
out = os.popen('date').read()

print out
