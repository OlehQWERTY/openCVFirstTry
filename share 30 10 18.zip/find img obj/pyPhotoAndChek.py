# call pyLaunchCV.py -> python3 mod_find_obj.py ../2experiment/opencv_frame_2.png ../1experiment/frame_0-cropped_1.png where autoImg.png
# image from web camera and ../1experiment/frame_0-cropped_1.png - part of surface under sole

# detect sole that is located above prew prepared surface (picture that looks like chess mash)

import os
import cv2

cam = cv2.VideoCapture(0)

# cv2.namedWindow("test")

img_counter = 0

for x in range(5):
    ret, frame = cam.read()
    cv2.imshow("test", frame)
    if not ret:
        break
    if x >=4:
        # SPACE pressed
        img_name = "autoImg.png" #img_name = "opencv_frame_{}.png".format(img_counter)
        cv2.imwrite(img_name, frame)
        # print("{} written!".format(img_name))

out = os.popen('python3 mod_find_obj.py autoImg.png ../1experiment/frame_0-cropped_1.png').read()
if out.find('inliers/matched')!= -1:
    print("No sole!")
else:
    print("Sole detected!")

cam.release()

# cv2.destroyAllWindows()
